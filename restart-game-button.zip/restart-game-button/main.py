import tkinter as tk 
from tkinter import ttk 

this_no=2 # Global 

def main():
  root = tk.Tk()
  root.geometry('300x200')
  root.resizable(False, False)
  root.title('Restart/Quit Game')

  restart_button = ttk.Button(
      root,
      text='Restart',
      command=restart_game
  )
  # restart_button.pack(ipadx=5, ipady=5, expand=True)
  restart_button.place(relx=0.3, rely=0.6)

  quit_button = ttk.Button(
    root,
    text='Quit Game',
    command=quit_game
  )
  # quit_button.pack(ipadx=5, ipady=5, expand=True)
  quit_button.place(relx=0.6, rely=0.6)

  root.mainloop()

def do_this():
    global this_no
    this_no+=1
    print(this_no)
  
def restart_game():
  global this_no
  this_no = 2  # Reset the global variable to its initial value
  print("Game Restarted. this_no reset to", this_no)
  # Add game restart functionalities here, ie revert back to the game modes page. reese and val 
  #withdraw from this page
  root.withdraw()
  #call the game modes page 
  #game_modes_page() should be smth like this hehe

def quit_game():
  root.quit() #Terminate the application 

def me():
  master = tk.Tk()
  master.title("Generated Numbers")
  tk.Button(master, text="Add Stuff", command=lambda: [do_this(), master.destroy()]).grid(row=1, column=1)
  master.mainloop() #quit game function 
  

if __name__ == "__main__":
  main()

  #displaying total score/Final Point - # must define score in the mainpage 

ScreenText(f"Score{score}",black,10,40,size=20,style="Calibri") 

