import time, random, datetime
import tkinter as tk


root = tk.Tk()


class Timer(tk.Frame):
  def __init__(self, seconds):
    super().__init__()
    self.seconds = seconds
    self.time_label = tk.Label(text="", font=("Codespace", 40))
    self.time_label.pack()
    self.start_timer()

  def start_timer(self):
    if self.seconds > 0:
      self.seconds -= 1
      self.time_label.config(text=str(datetime.timedelta(seconds=self.seconds)))
      self.time_label.after(1000, self.start_timer)


Timer(30)
root.mainloop()
                        
