import tkinter as tk
from random import shuffle
import time

class RecyclingGame:
    def __init__(self, master):
        self.master = master
        self.master.title("Recycling Game")

        self.create_widgets()

    def create_widgets(self):
        tk.Label(self.master, text="Select Difficulty Level:").pack()

        levels_frame = tk.Frame(self.master)
        levels_frame.pack()

        levels = ['easy', 'medium', 'hard']
        for level in levels:
            tk.Button(levels_frame, text=level.capitalize(), command=lambda l=level: self.start_game(l)).pack(side=tk.LEFT)

    def start_game(self, selected_level):
        items = self.generate_items(selected_level)
        timer_duration = self.get_timer_duration(selected_level)

        game_window = tk.Toplevel(self.master)
        GameWindow(game_window, items, timer_duration)

    def generate_items(self, selected_level):
        if selected_level == 'easy':
            return ['Paper', 'Plastic', 'Metal', 'General Waste']
        elif selected_level == 'medium':
            return ['Paper', 'Plastic', 'Metal', 'General Waste']
        elif selected_level == 'hard':
            return ['Paper', 'Plastic', 'Metal', 'General Waste']

    def get_timer_duration(self, selected_level):
        if selected_level == 'easy':
            return 60
        elif selected_level == 'medium':
            return 45
        elif selected_level == 'hard':
            return 30


class GameWindow:
    def __init__(self, master, items, timer_duration):
        self.master = master
        self.master.title("Sorting Game")

        self.items = items
        self.timer_duration = timer_duration
        self.start_time = None

        self.create_widgets()

    def create_widgets(self):
        tk.Label(self.master, text="Drag and drop the items to the correct bins:").pack()

        bins_frame = tk.Frame(self.master)
        bins_frame.pack()

        self.bins = {}
        for item in self.items:
            self.bins[item] = tk.Listbox(bins_frame, selectmode=tk.SINGLE, height=5)
            self.bins[item].pack(side=tk.LEFT)
            self.bins[item].insert(tk.END, item)

        for item, bin_listbox in self.bins.items():
            bin_listbox.bind("<B1-Motion>", lambda event, arg=item: self.on_drag(event, arg))

        self.start_time = time.time()
        self.master.after(int(self.timer_duration * 1000), self.check_time)

    def on_drag(self, event, item):
        widget = event.widget
        selected_index = widget.nearest(event.y)

        if selected_index >= 0:
            text = widget.get(selected_index)
            if text == item:
                widget.delete(selected_index)
                self.check_win()

    def check_win(self):
        for bin_listbox in self.bins.values():
            if bin_listbox.size() != 0:
                return

        tk.messagebox.showinfo("Congratulations!", "You sorted all items correctly!")
        self.master.destroy()

    def check_time(self):
        elapsed_time = time.time() - self.start_time
        if elapsed_time >= self.timer_duration:
            tk.messagebox.showinfo("Time's up!", "You ran out of time. Try again!")
            self.master.destroy()
        else:
            self.master.after(1000, self.check_time)


if __name__ == "__main__":
    root = tk.Tk()
    recycling_game = RecyclingGame(root)
    root.mainloop()
